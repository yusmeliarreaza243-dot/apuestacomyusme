async function mpPayment(id, token) {
  const r = await fetch(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(id)}`, { headers: { Authorization:`Bearer ${token}` } });
  const data = await r.json().catch(()=>({}));
  return { ok:r.ok, data };
}
// Retorna { order, error }. O erro NUNCA e' engolido: ele volta para o
// navegador, para voce enxergar o motivo real de os numeros nao sairem.
async function finalizeOrder(orderId, payment) {
  const url=process.env.SUPABASE_URL, service=process.env.SUPABASE_SERVICE_ROLE_KEY;
  if(!url||!service) return { order:null, error:'SUPABASE_URL ou SUPABASE_SERVICE_ROLE_KEY nao configurados no Vercel.' };
  try{
    const r=await fetch(`${url}/rest/v1/rpc/confirm_payment`,{method:'POST',headers:{apikey:service,Authorization:`Bearer ${service}`,'Content-Type':'application/json'},body:JSON.stringify({p_order_id:orderId,p_payment_id:String(payment.id),p_payment_status:String(payment.status),p_status_detail:String(payment.status_detail||''),p_paid_amount:Number(payment.transaction_amount||0)})});
    const data=await r.json().catch(()=>null);
    if(!r.ok){
      const msg=[data?.message,data?.details,data?.hint,data?.code].filter(Boolean).join(' | ')||`HTTP ${r.status}`;
      console.error('confirm_payment FALHOU:',msg,data);
      return { order:null, error:msg };
    }
    if(data && data.error){
      console.error('confirm_payment retornou erro:',data.error);
      return { order:null, error:String(data.error) };
    }
    return { order:data, error:null };
  }catch(e){
    console.error('confirm_payment exception:',e);
    return { order:null, error:e.message||'Erro ao chamar confirm_payment.' };
  }
}
export default async function handler(req,res){
  if(req.method!=='GET') return res.status(405).json({error:'Método não permitido.'});
  const token=process.env.MERCADOPAGO_ACCESS_TOKEN||process.env.MP_ACCESS_TOKEN||process.env.MERCADO_PAGO_ACCESS_TOKEN;
  const paymentId=req.query?.payment_id;
  if(!token) return res.status(500).json({error:'Mercado Pago não configurado.'});
  if(!paymentId) return res.status(400).json({error:'payment_id é obrigatório.'});
  try{
    const {ok,data:payment}=await mpPayment(paymentId,token);
    if(!ok) return res.status(400).json({error:'Não foi possível consultar o pagamento.'});
    const orderId=payment.external_reference||payment.metadata?.order_id||null;
    let finalized=null, finalizeError=null;
    if(payment.status==='approved' && orderId){
      const out=await finalizeOrder(orderId,payment);
      finalized=out.order; finalizeError=out.error;
    }else if(payment.status==='approved' && !orderId){
      finalizeError='O pagamento nao tem external_reference (order_id). Refaca a compra pelo site.';
    }
    return res.status(200).json({id:payment.id,status:payment.status,status_detail:payment.status_detail,amount:payment.transaction_amount,external_reference:orderId,metadata:payment.metadata||{},order:finalized,finalize_error:finalizeError});
  }catch(e){console.error('payment-status:',e);return res.status(500).json({error:'Erro interno ao consultar o pagamento.'});}
}
