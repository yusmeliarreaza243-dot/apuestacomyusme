async function supabaseUser(accessToken) {
  const url = process.env.SUPABASE_URL;
  const anon = process.env.SUPABASE_ANON_KEY;
  if (!url || !anon || !accessToken) return null;
  const r = await fetch(`${url}/auth/v1/user`, {
    headers: { apikey: anon, Authorization: `Bearer ${accessToken}` }
  });
  if (!r.ok) return null;
  return await r.json();
}

async function insertOrder(order) {
  const url = process.env.SUPABASE_URL;
  const service = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !service) throw new Error('Supabase não está configurado no servidor.');
  const r = await fetch(`${url}/rest/v1/orders`, {
    method: 'POST',
    headers: {
      apikey: service,
      Authorization: `Bearer ${service}`,
      'Content-Type': 'application/json',
      Prefer: 'return=representation'
    },
    body: JSON.stringify(order)
  });
  const data = await r.json().catch(()=>null);
  if (!r.ok) throw new Error(data?.message || data?.hint || 'Não foi possível criar a compra.');
  return Array.isArray(data) ? data[0] : data;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método não permitido.' });
  try {
    const { raffle, raffleId, quantity, amount, customerName, customerPhone, authToken } = req.body || {};
    const qty = Number(quantity);
    const total = Number(amount);
    if (!raffle || !raffleId || !Number.isInteger(qty) || qty < 1 || qty > 100 || !Number.isFinite(total) || total <= 0) {
      return res.status(400).json({ error: 'Dados da rifa, quantidade ou valor inválidos.' });
    }

    const user = await supabaseUser(authToken);
    if (!user?.id) return res.status(401).json({ error: 'Faça login antes de participar da rifa.' });

    const accessToken = process.env.MERCADOPAGO_ACCESS_TOKEN || process.env.MP_ACCESS_TOKEN || process.env.MERCADO_PAGO_ACCESS_TOKEN;
    if (!accessToken) return res.status(500).json({ error: 'A credencial do Mercado Pago não está configurada nas Environment Variables.' });

    const orderId = crypto.randomUUID();
    await insertOrder({
      id: orderId,
      user_id: user.id,
      raffle_id: String(raffleId),
      raffle_name: String(raffle),
      quantity: qty,
      amount: Number(total.toFixed(2)),
      customer_name: String(customerName || user.user_metadata?.full_name || ''),
      customer_phone: String(customerPhone || user.user_metadata?.phone || ''),
      status: 'pending'
    });

    const origin = `https://${req.headers.host}`;
    const preference = {
      items: [{ title: `${raffle} — ${qty} número(s)`, quantity: 1, currency_id: 'BRL', unit_price: Number(total.toFixed(2)) }],
      payer: { name: customerName || undefined, email: user.email || undefined, phone: customerPhone ? { number: String(customerPhone).replace(/\D/g,'') } : undefined },
      external_reference: orderId,
      metadata: { order_id: orderId, raffle_id: String(raffleId), raffle: String(raffle), quantity: qty, user_id: user.id },
      back_urls: { success: `${origin}/?pagamento=sucesso`, pending: `${origin}/?pagamento=pendente`, failure: `${origin}/?pagamento=falhou` },
      auto_return: 'approved',
      // Sem notification_url o Mercado Pago nunca chama o webhook:
      // o Pix pago depois de fechar a página ficaria sem números.
      notification_url: `${origin}/api/mp-webhook`
    };

    const mpResponse = await fetch('https://api.mercadopago.com/checkout/preferences', {
      method: 'POST',
      headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(preference)
    });
    const data = await mpResponse.json();
    if (!mpResponse.ok) return res.status(mpResponse.status).json({ error: 'O Mercado Pago recusou a criação do checkout.' });

    // Save the preference ID without exposing the service role key to the browser.
    const supa = process.env.SUPABASE_URL, service = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (supa && service) {
      await fetch(`${supa}/rest/v1/orders?id=eq.${encodeURIComponent(orderId)}`, {
        method:'PATCH', headers:{apikey:service,Authorization:`Bearer ${service}`,'Content-Type':'application/json',Prefer:'return=minimal'},
        body:JSON.stringify({ preference_id:data.id, external_reference:orderId })
      });
    }
    return res.status(200).json({ init_point: data.init_point, preference_id: data.id, order_id: orderId });
  } catch (error) {
    console.error('create-preference:', error);
    return res.status(500).json({ error: error.message || 'Erro interno ao criar o pagamento.' });
  }
}
