export default function handler(req, res) {
  res.setHeader('Cache-Control','no-store');
  const supabaseUrl = process.env.SUPABASE_URL || '';
  const supabaseAnonKey = process.env.SUPABASE_ANON_KEY || '';
  const missing = [];
  if (!supabaseUrl) missing.push('SUPABASE_URL');
  if (!supabaseAnonKey) missing.push('SUPABASE_ANON_KEY');
  return res.status(200).json({ supabaseUrl, supabaseAnonKey, configured: missing.length === 0, missing });
}
