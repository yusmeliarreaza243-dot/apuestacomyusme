async function finalizeOrder(orderId,payment){
  const url=process.env.SUPABASE_URL, service=process.env.SUPABASE_SERVICE_ROLE_KEY;
  if(!url||!service) throw new Error('Supabase não configurado.');
  const r=await fetch(`${url}/rest/v1/rpc/confirm_payment`,{method:'POST',headers:{apikey:service,Authorization:`Bearer ${service}`,'Content-Type':'application/json'},body:JSON.stringify({p_order_id:orderId,p_payment_id:String(payment.id),p_payment_status:String(payment.status),p_status_detail:String(payment.status_detail||''),p_paid_amount:Number(payment.transaction_amount||0)})});
  const data=await r.json().catch(()=>null);
  if(!r.ok) throw new Error([data?.message,data?.details,data?.hint,data?.code].filter(Boolean).join(' | ')||`HTTP ${r.status}`);
  if(data && data.error) throw new Error(String(data.error));
  return data;
}
export default async function handler(req,res){
  if(req.method!=='POST'&&req.method!=='GET') return res.status(405).json({error:'Método não permitido'});
  try{
    const token=process.env.MERCADOPAGO_ACCESS_TOKEN||process.env.MP_ACCESS_TOKEN||process.env.MERCADO_PAGO_ACCESS_TOKEN;
    if(!token) return res.status(500).json({error:'Mercado Pago não configurado'});
    const body=req.body||{}, query=req.query||{};
    const paymentId=body?.data?.id||body?.id||query?.['data.id']||query?.id;
    if(!paymentId) return res.status(200).json({received:true,processed:false});
    const r=await fetch(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(paymentId)}`,{headers:{Authorization:`Bearer ${token}`}});
    const payment=await r.json();
    if(!r.ok) return res.status(200).json({received:true,processed:false});
    const orderId=payment.external_reference||payment.metadata?.order_id;
    let order=null;
    if(payment.status==='approved'&&orderId) order=await finalizeOrder(orderId,payment);
    console.log('Mercado Pago webhook', {paymentId,status:payment.status,orderId});
    return res.status(200).json({received:true,processed:true,status:payment.status,order});
  }catch(e){console.error('mp-webhook ERRO:',e?.message||e);return res.status(200).json({received:true,processed:false,error:e?.message||String(e)});}
}
